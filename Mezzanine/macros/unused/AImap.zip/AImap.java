// STAR-CCM+ macro: AImap.java
package AImap;

import star.common.*;

/**
 *
 * @author Adrian Engeländer, CD-adapco.
 */
// in 8.04 and older data points can actually be outside the map, which is 
// some kind of round off error.
public class AImap extends StarMacro {

    String fileSeparator = "/"; // just set a default.

    @Override
    public void execute() {
        Simulation sim = getActiveSimulation();

        sim.println("\nSetting up AI Map.");

        fileSeparator = System.getProperty("file.separator");

        String boundsFile = "bounds.csv";

        // sim.println("sdir: "+sim.getSessionDir()+fileSeparator);
        //sim.println("spath: "+sim.getSessionPath());

        try {
            // http://stackoverflow.com/questions/18443315/is-it-possible-how-to-embed-and-access-html-files-in-a-jar
            // path is relative to macro.
            boundsFile = sim.getSessionDir() + fileSeparator + "bounds.csv";
            Tools.IOTempFile.copyStream("bounds.csv", boundsFile, getClass(), sim);            

            //wrong: copyStream("AImap/bounds.csv",sim.getSessionDir()+"/"+"bounds2.csv",sim);

            // String pathToFile = "./bounds.csv"; file see below
            // magic.GlobalServices.copy(theFile, new File("/users/miami2/adrian/tmp/"));
        } catch (Exception ex) {
            sim.println("Error local 2: " + ex.toString());
        }

        // create the fields
        if (!sim.getFieldFunctionManager().hasFunction("0_TKE")) {
            UserFieldFunction uff_tke = sim.getFieldFunctionManager().createFieldFunction();
            uff_tke.setPresentationName("0_TKE");
            uff_tke.setFunctionName("TKE");
            uff_tke.getTypeOption().setSelected(FieldFunctionTypeOption.SCALAR);
            uff_tke.setDefinition("$UU_Stress+$VV_Stress+$WW_Stress");
        } else {
            sim.println("Some field functions already exist. Errors may occur. Please clean your simulation and run the macro again.");
        }

        if (!sim.getFieldFunctionManager().hasFunction("0_Trace")) {
            UserFieldFunction uff_trace = sim.getFieldFunctionManager().createFieldFunction();
            uff_trace.setPresentationName("0_Trace");
            uff_trace.setFunctionName("trace");
            uff_trace.getTypeOption().setSelected(FieldFunctionTypeOption.SCALAR);
            uff_trace.setDefinition("$$a1[0]+$$a2[1]+$$a3[2]");
        } else {
            sim.println("Some field functions already exist. Errors may occur. Please clean your simulation and run the macro again.");
        }

        if (!sim.getFieldFunctionManager().hasFunction("0_a1")) {
            UserFieldFunction uff_a1 = sim.getFieldFunctionManager().createFieldFunction();
            uff_a1.setPresentationName("0_a1");
            uff_a1.setFunctionName("a1");
            uff_a1.getTypeOption().setSelected(FieldFunctionTypeOption.VECTOR);
            uff_a1.setDefinition("[$UU_Stress/$TKE-1/3,$UV_Stress/$TKE,$UW_Stress/$TKE]");
        } else {
            sim.println("Some field functions already exist. Errors may occur. Please clean your simulation and run the macro again.");
        }

        if (!sim.getFieldFunctionManager().hasFunction("0_a2")) {
            UserFieldFunction uff_a2 = sim.getFieldFunctionManager().createFieldFunction();
            uff_a2.setPresentationName("0_a2");
            uff_a2.setFunctionName("a2");
            uff_a2.getTypeOption().setSelected(FieldFunctionTypeOption.VECTOR);
            uff_a2.setDefinition("[$UV_Stress/$TKE,$VV_Stress/$TKE-1/3,$VW_Stress/$TKE]");
        } else {
            sim.println("Some field functions already exist. Errors may occur. Please clean your simulation and run the macro again.");
        }

        if (!sim.getFieldFunctionManager().hasFunction("0_a3")) {
            UserFieldFunction uff_a3 = sim.getFieldFunctionManager().createFieldFunction();
            uff_a3.setPresentationName("0_a3");
            uff_a3.setFunctionName("a3");
            uff_a3.getTypeOption().setSelected(FieldFunctionTypeOption.VECTOR);
            uff_a3.setDefinition("[$UW_Stress/$TKE,$VW_Stress/$TKE,$WW_Stress/$TKE-1/3]");
        } else {
            sim.println("Some field functions already exist. Errors may occur. Please clean your simulation and run the macro again.");
        }

        if (!sim.getFieldFunctionManager().hasFunction("0_IIa")) {
            UserFieldFunction uff_IIa = sim.getFieldFunctionManager().createFieldFunction();
            uff_IIa.setPresentationName("0_IIa");
            uff_IIa.setFunctionName("IIa");
            uff_IIa.getTypeOption().setSelected(FieldFunctionTypeOption.SCALAR);
            uff_IIa.setDefinition("pow($$a1[0],2)+pow($$a2[1],2)+pow($$a3[2],2)+2*(pow($$a1[1],2)+pow($$a1[2],2)+pow($$a2[2],2))");
        } else {
            sim.println("Some field functions already exist. Errors may occur. Please clean your simulation and run the macro again.");
        }

        if (!sim.getFieldFunctionManager().hasFunction("0_IIIa")) {
            UserFieldFunction uff_IIIa = sim.getFieldFunctionManager().createFieldFunction();
            uff_IIIa.setPresentationName("0_IIIa");
            uff_IIIa.setFunctionName("IIIa");
            uff_IIIa.getTypeOption().setSelected(FieldFunctionTypeOption.SCALAR);
            uff_IIIa.setDefinition("pow($$a1[0],3)+pow($$a2[1],3)+pow($$a3[2],3)+3*(($$a1[0]+$$a2[1])*pow($$a1[1],2)+($$a1[0]+$$a3[2])*pow($$a1[2],2)+($$a2[1]+$$a3[2])*pow($$a2[2],2))+6*($$a1[1]*$$a1[2]*$$a2[2])");
        } else {
            sim.println("Some field functions already exist. Errors may occur. Please clean your simulation and run the macro again.");
        }

        UserFieldFunction uff_IIa = (UserFieldFunction) sim.getFieldFunctionManager().getFunction("IIa");
        UserFieldFunction uff_IIIa = (UserFieldFunction) sim.getFieldFunctionManager().getFunction("IIIa");

        // make plot

        XYPlot xYPlot_2 = sim.getPlotManager().createXYPlot();

        // xYPlot_2.refreshAndWait();

        AxisType axisType_0 = xYPlot_2.getXAxisType();
        axisType_0.setMode(1);
        axisType_0.setFieldFunction(uff_IIIa);

        YAxisType yAxisType_1 = ((YAxisType) xYPlot_2.getYAxes().getAxisType("Y Type 1"));
        yAxisType_1.setFieldFunction(uff_IIa);

        xYPlot_2.setPresentationName("Invariants");

        Axes axes_2 = xYPlot_2.getAxes();

        Axis axis_4 = axes_2.getXAxis();
        AxisTitle axisTitle_4 = axis_4.getTitle();
        axisTitle_4.setText("0_IIIa");

        Axis axis_5 = axes_2.getYAxis();
        AxisTitle axisTitle_5 = axis_5.getTitle();
        axisTitle_5.setText("0_IIa");

        // get the bounds

        FileTable fileTable_0 = (FileTable) sim.getTableManager().createFromFile(resolvePath(boundsFile));

        ExternalDataSet externalDataSet_1 = sim.getDataSetManager().createExternalDataSet(xYPlot_2);

        xYPlot_2.getDataSetGroup().addObjects(externalDataSet_1);
        xYPlot_2.getExternal().add(externalDataSet_1);

        externalDataSet_1.setTable(fileTable_0);
        externalDataSet_1.setXValuesName("IIIa");
        externalDataSet_1.setYValuesName("IIa");

        // line style of bounds
        LineStyle lineStyle_1 = externalDataSet_1.getLineStyle();
        lineStyle_1.setStyle(1);
        SymbolStyle symbolStyle_1 = externalDataSet_1.getSymbolStyle();
        symbolStyle_1.setStyle(0);

        // finish
        sim.println("\nAI environment setup finished.\nYou now need to set the (derived) input parts for the \"Invariants\"-Plot.\n");
    }
}
