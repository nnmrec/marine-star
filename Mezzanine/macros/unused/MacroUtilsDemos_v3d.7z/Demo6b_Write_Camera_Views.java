import macroutils.*;

public class Demo6b_Write_Camera_Views extends MacroUtils {

  public void execute() {
    _initUtils();
    writeCameraViews("myCameras.txt");
  }
  
}
